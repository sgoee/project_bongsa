import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

df = pd.read_csv("HousingData.csv").dropna()

X = df[["LM", "LSTAT"]]
Y = df["MEVD"]

X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y, test_size=0.2, random_state=42
)

model = LinearRegression()
model.fit(X_train, Y_train)

print("\n기울기:")
for name, coef in zip(X.columns, model.coef_):
    print(f"{name}: {coef}")

print("\n절편:", model.intercept_)

print("R2:", model.score(X_test, Y_test))

X_one = float(input("\n첫번째 변수의 값을 입력하세요: "))
X_two = float(input("두번째 변수의 값을 입력하세요: "))

pred = model.predict([[X_one, X_two]])

print("예측 결과:", pred[0])