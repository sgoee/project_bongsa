import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split

df = pd.read_csv("Iris.csv").dropna()

X = df[["PetalLengthCm", "PetalWidthCm"]]
Y = df["Species"]

X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y, test_size=0.2, random_state=42
)

model = DecisionTreeClassifier(max_depth=3)
model.fit(X_train, Y_train)

print("R2:", model.score(X_test, Y_test))

X_one = float(input("\n첫번째 변수의 값을 입력하세요: "))
X_two = float(input("두번째 변수의 값을 입력하세요: "))

pred = model.predict([[X_one, X_two]])

print("예측 결과:", pred[0])